using System;

namespace Restaurante.Dominio { 
    
    public class Menu { 
      public  int id {get; set;}
      public  string descripcion {get; set;}
      public  int precio {get; set;}

    }   
}