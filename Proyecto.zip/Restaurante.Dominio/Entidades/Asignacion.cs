using System;

namespace Restaurante.Dominio{
    
    public class Asignacion { 

       public int id {get; set;}    
       public Persona persona {get; set;}

    }
}