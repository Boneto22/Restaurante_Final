using System;

namespace Restaurante.Dominio { 
    
    public class Rol: Persona  { 
      //public  int id {get; set;}
      public  string tipoRol{get; set;} 
      public  string password {get; set;}
      
    } 

}