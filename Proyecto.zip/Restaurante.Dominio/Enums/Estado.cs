using System;

namespace Restaurante.Dominio { 
    public enum Estado { 
        Activo, 
        Inactivo
    
       
    }
}