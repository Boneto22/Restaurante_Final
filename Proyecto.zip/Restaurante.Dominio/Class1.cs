﻿using System;

namespace Restaurante.Dominio
{
    public class Class1
    {
    }
}
