using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace restaurante.app.webapp.pages
{
    public class ComidasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
