using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Restaurante.App.WebApp.Pages.Menu
{
    public class CarritoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
