using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Restaurante.App.WebApp.Pages.Menu
{
    public class MesaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
