using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace restaurante.app.webapp.pages
{
    public class ClienteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
