﻿using System;

namespace Restaurante.Persistencia
{
    public class Class1
    {
    }
}
